# Scheduled routine — setup

The daily publish is a **Claude Code routine** (scheduled cloud agent) on your Claude
Enterprise instance. It runs the kit end‑to‑end each morning.

## How to create it

In Claude Code (Enterprise), either:
- run the **`/schedule`** command and follow the prompts, or
- open the **routines** UI (Claude Code → Routines) and create a new one.

Fill it in with the settings below.

## Settings

| Field | Value |
|---|---|
| **Name** | `Daily Intel → Pages mirror` |
| **Schedule (cron, UTC)** | `0 14 * * *`  (= 07:00 America/Los_Angeles during PDT; see DST note) |
| **Model** | `claude-sonnet-5` |
| **Repositories / sources** | attach **both** the source repo and the public repo |
| **Allowed tools** | `Bash, Read, Write, Edit, Glob, Grep, Artifact` |
| **Environment** | your default cloud environment |

DST note: cron is fixed UTC. `0 14 * * *` is 07:00 PT while daylight time is in effect
and 06:00 PT in winter — nudge the hour by one after clocks change if you want it pinned.

## Prompt

Paste this as the routine's message. **Edit the two placeholders**: the source repo URL
and the artifact URL (they must match `config.py`).

```
You mirror the latest "Daily Intel" artifact to the public site. Fully automated — do not ask for confirmation.

The source repo <SOURCE-REPO-URL> is cloned into your workspace (find its root with: find / -maxdepth 6 -iname launch.sh). cd into that repo root for ALL commands.

IMPORTANT: Do NOT cat, cp, move, open, or reference any file path under a ".claude" directory in a shell command — those are permission-blocked and will stall the run. The import script locates the file itself.

STEP 1 — FETCH THE LATEST ARTIFACT
Call the Artifact tool: action "read", url "<ARTIFACT-URL>". This automatically saves the full artifact HTML into the workspace. You do NOT need to move, copy, or open that file.

STEP 2 — IMPORT INTO index.html
From the repo root run exactly: python3 import_artifact.py
The script auto-discovers the artifact export that the read just saved, strips the runtime wrapper, and writes a clean standalone index.html. If it exits non-zero, STOP and report the exact stderr — do NOT publish.

STEP 3 — PUBLISH
From the repo root run: ./launch.sh --no-open
This regenerates the Markdown/HTML archives, updates the "Past Editions" index, commits and pushes to origin, and publishes the public page.

STEP 4 — VERIFY & REPORT
Confirm launch.sh exited 0 and that its output contains BOTH a successful push to origin AND a line "published → <PUBLIC-SITE-URL>/". If EITHER git push failed (e.g. authentication/permission denied in the sandbox), quote the exact error, state which step failed, and note whether index.html was at least updated locally. End with a one-line summary naming the edition date now published (from the 'Edition' line in index.html).
```

## Before you rely on it

1. Confirm the **Claude GitHub App** is installed with **write** on both repos
   (README §6.1) — without it the push fails with a 403.
2. **Trigger the routine once manually** and read the run log. A healthy run ends with
   `published → …` and both pushes succeeding.
3. Only then leave it on the daily schedule.
