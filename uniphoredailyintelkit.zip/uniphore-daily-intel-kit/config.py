"""Deployment configuration for the Daily Intel publishing pipeline.

Edit the four values below for your environment, then everything else
(generate_report.py, import_artifact.py, launch.sh) reads from here.
This is the ONLY file you should need to change to redeploy.
"""

# The public site root where the page is served (no trailing slash).
# For GitHub Pages this is https://<org>.github.io/<public-repo>.
# For internal hosting, use whatever URL your static host serves the page at.
PUBLIC_SITE = "https://ORG.github.io/PUBLIC-REPO"

# Git URL of the PUBLIC repo whose root is served as the site (index.html,
# editions/, archive.html). launch.sh clones this, syncs public/, and pushes.
# For non-GitHub hosting, see README "Adapting the publish step".
PUBLIC_REMOTE = "https://github.com/ORG/PUBLIC-REPO.git"

# The Claude artifact that holds the authored daily edition, mirrored by
# import_artifact.py. Full URL + the id prefix (first path segment of the id).
ARTIFACT_URL = "https://claude.ai/code/artifact/REPLACE-WITH-ARTIFACT-ID"
ARTIFACT_ID = "REPLACE"  # leading segment of the artifact id, e.g. "665af250"
